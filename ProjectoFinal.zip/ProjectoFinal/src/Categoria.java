public enum Categoria {

}
